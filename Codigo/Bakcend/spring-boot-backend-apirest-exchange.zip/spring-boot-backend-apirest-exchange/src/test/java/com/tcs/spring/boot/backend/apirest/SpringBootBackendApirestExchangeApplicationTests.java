package com.tcs.spring.boot.backend.apirest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBackendApirestExchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
