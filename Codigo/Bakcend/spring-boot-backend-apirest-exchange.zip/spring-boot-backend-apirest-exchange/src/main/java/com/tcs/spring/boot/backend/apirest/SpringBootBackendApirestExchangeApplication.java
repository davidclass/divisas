package com.tcs.spring.boot.backend.apirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBackendApirestExchangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBackendApirestExchangeApplication.class, args);
	}

}
